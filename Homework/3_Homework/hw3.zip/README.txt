You will use this exact Makefile for your Homework 3. If you need to change it, please consult with me first.

You can compile everything by typing 

make clean
make all

You can compile one program individually by just typing make <Program Name>, for example

make query_tree

By typing 

make clean

You delete all .o files and executables.

--Note that file avl_tree_mod.h is not provided.
