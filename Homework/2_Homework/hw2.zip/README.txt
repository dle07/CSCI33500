You will use this exact Makefile for your Homework #2.
Failure to do so will result in deduction of points.

To compile on terminal type
  make clean
  make all

To delete executables and object file type
  make clean

To run:

./test_points2d

^^In that case you will provide input from standard input.

To run with a given file that is redirected to standard input:

./test_points2d < test_input_file.txt
